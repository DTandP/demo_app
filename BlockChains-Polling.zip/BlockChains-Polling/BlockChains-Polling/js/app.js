var app=angular.module('Block_Chains_Polling',["ngRoute"]);


//service to save th polling information into an object
app.service('PollService',function(){


    var pollArray=[];

    this.save=function(Poll_From_Form)
    {

//console.log(Poll_From_Form);
//pollArray.push(Poll_From_Form);
    var poll={};
//var poll=[];

    poll["pollQuestion"]=Poll_From_Form.question;
    poll["pollChoices"]=Poll_From_Form.options;

/*
for(var i=0;i<Poll_From_Form.options.length;i++){

poll.responses[i]=Poll_From_Form.options[i];

}*/




    pollArray.push(poll);

    }

    this.showPollData=function()
    {

   // console.log(pollArray);
        return pollArray;
    }

});



//Controller for static content on Main.html page
app.controller('pollStaticController',function($scope,$location){

$scope.nav = {};
    $scope.nav.isActive = function(path) {
        if (path === $location.path()) {
            return true;
        }
        
        return false;
    }


});




//Controller for handling Polling_form.html page


app.controller('PollingFormController',function($scope,$location,$compile,PollService){

$scope.showNewPoll=false;
$scope.countBox =0;
$scope.boxName = 0;
$scope.previousPollData;

$scope.createNewPoll=function(){
$scope.showNewPoll=true
$scope.newPoll = {};
$scope.newPoll.options=[];

}

$scope.go = function ( path ) {
  $location.path( path );
};

$scope.addInputField=function()
{
     var boxName="Option "+$scope.countBox; 
/*document.getElementById('pollTextInput').innerHTML+='<br><input ng-model="newPoll.options" type="text" id="PollOption'+$scope.countBox+'" value="'+$scope.boxName+'" "  /><br/>';*/
var input=document.createElement('input'); 

var inputSpace=document.createElement('div');     
var parent=document.getElementById('pollTextInput');

    input.setAttribute("ng-model", "newPoll.options["+$scope.countBox+"]");
    input.setAttribute("value",$scope.boxName);
    input.setAttribute("style","margin:6px")
    input.setAttribute("type", "text");
    input.setAttribute("id", "PollOption"+$scope.countBox);

 $compile(input)($scope);
     $scope.countBox += 1;
parent.appendChild(inputSpace);
parent.appendChild(input);
}




$scope.savePollInfo=function(){

//console.log($scope.newPoll);

PollService.save($scope.newPoll);
        $scope.newPoll = {};    
        $scope.newPoll.options=[];

        alert("Your Poll is now live.\nYou can create more Polls below...");
}

$scope.showAllPolls=function(){

$scope.previousPollData=PollService.showPollData();
      //$location.path( "#/castVote" );
    console.log($scope.previousPollData);
}

});



//Controller for handling Voting_Panel.html page

app.controller('VotingPanelController',function($scope,PollService){


//    $scope.votingList=[];

$scope.votingList=PollService.showPollData();

/*$scope.selectedValues={};
$scope.selectedValues.chosen=[];*/
//$scope.selectedValues.answers=[];

$scope.selected = [];
   

$scope.registerVote=function(data,question){

//data variable is used for getting the options of the POLL
//question variable is used for getting the question of the POLL
console.log(data);
//test code for checkbox
/*var arr = [];
    for(var i in data){
       if(data[i].SELECTED=='Y'){
           arr.push(data[i].id);
       }
    }
    console.log(arr);
    $scope.selected = arr;*/

//test code ends



//    console.log($scope.selectedValues);

alert("Your response for "+question+" has been registered.\nThanks for voting...");

/*for(var i=0;i<$scope.votingList.length;i++){

    console.log("Live Poll list modifications here");
}
*/



}

/*$scope.test=function(){

    console.log($scope.votingList);
}
*/

});




//Config function for SPA architecture

app.config(function($routeProvider){

$routeProvider
    /*.when("/", {
        templateUrl : "partials/Polling_Form.html"
    })*/
    .when("/createPoll", {
        templateUrl : "partials/Polling_Form.html",
        controller  :  "PollingFormController"
    })
    .when("/castVote", {
        templateUrl : "partials/Voting_Panel.html",
        controller  :  "VotingPanelController"
    })
    .otherwise({
       redirectTo: "/createPoll"
    }); 


});